function submit() {
    class Mahasiswa {
        constructor(id_mhs, name, sex, year) {
            this.id_mhs = id_mhs;
            this.name = name;
            this.sex = sex;
            this.year = year;
        }
        getMahasiswaInfo(present_year) {
            console.log(present_year, this.year);
            let semester = (present_year - this.year)*2;
            let info = "Nim anda: <b>" + this.id_mhs + "</b>,/nNama anda: <b>" + this.name + "</b>,/nJenis Kelamin anda: <b>" + this.sex + "</b>,/n/nTahun Masuk Anda: " + this.year + ",/ndan anda berarti sekarang/nsemester: <b>" + semester + "</b>";
            return info;
        }
    }

    var id_mhs = document.getElementById("nim").value;
    var name = document.getElementById("nama").value;
    var sex = document.querySelector('input[name="jns_kelamin"]:checked').value;
    var year = document.getElementById("tahun").value;
    
    let numberValidated = /^[0-9]+$/;
    let letterValidated = /^[a-zA-Z]+$/;
    let date = new Date();
    let tahun = date.getFullYear();
    let windowPopUp = window.open('result.html', '', 'width=640, height=480');

    if(id_mhs !== "" && name !== "" && sex !== "" && year !== "") {
        if (id_mhs.match(numberValidated)) {
            if(name.match(letterValidated)) {
                if(year.match(numberValidated) && year.length == 4 && year <= tahun) {
                    alert("Pengisian Berhasil!");
                    windowPopUp.addEventListener('load', function () {
                        let myStudent = new Mahasiswa(id_mhs, name, sex, year);
                        windowPopUp.postMessage(document.write(myStudent.getMahasiswaInfo(tahun)), '*');
                    });
                }else {
                    alert("Masukan tahun anda salah!\nFormat wajib 4 angka dan maksimal sampai tahun sekarang!");
                    tahun="";
                    tahun.focus();
                    return false;
                }
            }else {
                alert("Masukan nama anda salah!\nFormat wajib huruf!");
                nama="";
                nama.focus();
                return false;
            }
        }else {
            alert("Masukan NIM anda salah!\nFormat wajib angka!");
            nim="";
            nim.focus();
            return false;
        }
    }else {
        alert("Semua field wajib diisi!");
        nim="";
        nama="";
        tahun="";
        return false;
    }
}