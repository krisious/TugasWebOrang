function formValidasi() {
  var nim = document.getElementById("nim").value;
  var nama = document.getElementById("nama").value;
  var jk = document.querySelector("input[name='jns_kelamin']:checked");
  var thMasuk = document.getElementById("thMasuk").value;
  var validasiAngka = /^[0-9]+$/;
  var validasiHuruf = /^[a-zA-Z ]+$/;

  if (nim == "" || !nim.match(validasiAngka)) {
    alert("NIM Tidak Boleh Kosong dan Harus Berupa Angka!");
    // nim.focus();
  } else if (nama == "" || !nama.match(validasiHuruf)) {
    alert("Nama Tidak Boleh Kosong dan Harus Berupa Huruf!");
    nama.focus();
  } else if (!jk) {
    alert("Jenis Kelamin Tidak Boleh Kosong!");
  } else if (thMasuk == "" || !thMasuk.match(validasiAngka)) {
    alert("Tahun Masuk Tidak Boleh Kosong dan Harus Berupa Angka!");
    thMasuk.value.focus();
  } else {
    console.log(nim + nama + jk + thMasuk);
    tampilkan();
  }
}

function tampilkan() {
  var popup = window.open("popup.html", "", "width=640, height=480");
  popup.addEventListener("load", function () {
    var jk = document.querySelector("input[name='jns_kelamin']:checked");
    var thnSkrng = new Date();
    var tahun = thnSkrng.getFullYear();
    var semester = (tahun - thMasuk.value) * 2;

    var result =
      "Nim Anda : " +
      nim.value +
      ",<br> Nama Anda: " +
      nama.value +
      ",<br>Jenis Kelamin Anda: " +
      jk +
      ",<br><br> Tahun Masuk:" +
      thMasuk.value +
      "<br> dan Anda berarti sekarang semester: " +
      semester;

    popupWindow.postMessage(result, "*");
  });
}

//   if (document.forms["formDataMhs"]["nama"].value == "") {
//     alert("Nama Tidak Boleh Kosong!");
//     document.forms["formDataMhs"]["nama"].focus();
//     return false;
//   }
//   if (document.forms["formDataMhs"]["tahunMasuk"].value == "") {
//     alert("Tahun Masuk Tidak Boleh Kosong!");
//     document.forms["formDataMhs"]["tahunMasuk"].focus();
//     return false;
//   }

//   document.write("NIM Anda: " + nim.value);
//   document.write("Nama Anda: " + nama.value);
//   document.write("Jenis Kelamin Anda: " + jk.value);
//   document.write("Tahun Masuk Anda: " + thMasuk.value);
