function submit() {
    var nama = document.getElementById("nama");
    var nim = document.getElementById("nim");
    var kelamin = document.querySelector("input[name='jeniskelamin']:checked");
    var tahun = document.getElementById("tahun");
    
    var validasiHuruf = /^[a-zA-Z ]+$/;
    var validasiAngka = /^[0-9]+$/;
    
    if(nama.value.match(validasiHuruf)){
        if(nim.value.match(validasiAngka)){
            if(!kelamin){
                alert("Anda Harus memilih jenis kelamin");
            }else{
                if(tahun.value.match(validasiAngka)){
                    popup(nama, nim, kelamin, tahun);
                }else{
                    alert("Masukkan Tahun Anda Salah!\nFormat wajib Angka!");
                    tahun.value="";
                    tahun.focus();
                    return false;
                }
            }
        }else{
          alert("Masukkan Nim Anda Salah!\nFormat wajib Angka!");
          nim.value="";
          nim.focus();
          return false;
        }
    }else{
      alert("Masukkan nama Anda Salah!\nFormat wajib Huruf!");
      nama.value="";
      nama.focus();
      return false;
    }
    
}

function popup(nama, nim, kelamin, tahun){
    var popup = window.open('tugas1_2.html', '', 'width=640, height=480');
    var tahunini = new Date();
    var thn = tahunini.getFullYear();
    var semester = (thn - tahun) * 2;

    var hasil = "Nama Anda: <b>" + nama.value +"</b>" + 
    "<br>NIM anda: <b>" + nim.value +"</b>," + 
    "<br>Jenis Kelamin anda: <b>" + kelamin.value +"</b>" + 
    "<br>tahun masuk anda: <b>" + tahun.value + "</b>" +
    "<br>dan anda berarti sekarang" +
    "<br>semester: <b>" + semester + "</b>";

    popup.postMessage(hasil, "*");
}